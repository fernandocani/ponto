//
//  DataStore.swift
//  
//
//  Created by Fernando Cani on 8/24/15.
//
//

import UIKit
import CoreData

class DataStore {
    let managedContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext!
    
    // MARK: - Singleton
    class var sharedInstance: DataStore {
        struct Static {
            static let instance: DataStore = DataStore()
        }
        return Static.instance
    }
    
    // MARK: - Create (Record)
    
    func saveData(Date date: NSDate, Time1 time1: String, Time2 time2: String, Time3 time3: String, Time4 time4: String, Comment comment: String, TotalHor totalHor: Int16, TotalMin totalMin: Int16) -> Bool {
        if getRecordByDate(date) == nil {
            let userEntity = NSEntityDescription.entityForName("Record", inManagedObjectContext: managedContext)
            let record = Record(entity: userEntity!, insertIntoManagedObjectContext: managedContext)
            record.totalHor = totalHor
            record.totalMin = totalMin
            record.comment = comment
            record.time4 = time4
            record.time3 = time3
            record.time2 = time2
            record.time1 = time1
            record.date = date
            var error: NSError?
            return managedContext.save(&error)
        } else {
            return false
        }
    }
    
    // MARK: - Read (Record)

    func getAllRecords() -> NSArray {
        let request = NSFetchRequest(entityName: "Record")
        var error: NSError?
        let recordList = managedContext.executeFetchRequest(request, error: &error) as! [Record]?
        var recordArray = NSArray(array: recordList!)
        return recordArray
    }
    
    func getRecordByID(id: Int) -> Record! {
        let request = NSFetchRequest(entityName: "Registro")
        let predicate = NSPredicate(format: "id LIKE[cd] %@", id)
        request.predicate = predicate
        var error: NSError?
        var objects = managedContext.executeFetchRequest(request, error: &error)
        if objects!.count > 0 {
            let match = objects?.first as! Record
            return match
        } else {
            return nil
        }
    }
    
    func getRecordByDate(date: NSDate) -> Record! {
        let request = NSFetchRequest(entityName: "Record")
        let predicate = NSPredicate(format: "date == %@", date)
        request.predicate = predicate
        var error: NSError?
        var objects = managedContext.executeFetchRequest(request, error: &error)
        if objects!.count > 0 {
            return objects!.first as! Record
        } else {
            return nil
        }
    }
    
    // MARK: - Update (Record)
    
    func updateRecordByDate(CurrentDate currentDate: NSDate, SaveDate saveDate: NSDate, Time1 time1: String, Time2 time2: String, Time3 time3: String, Time4 time4: String, Comment comment: String, TotalHor totalHor: Int16, TotalMin totalMin: Int16) -> Bool {
        let request = NSFetchRequest(entityName: "Record")
        let predicate = NSPredicate(format: "date == %@", currentDate)
        request.predicate = predicate
        var error: NSError?
        let recordList = managedContext.executeFetchRequest(request, error: &error) as! [Record]
        if recordList.count > 0 {
            let request2 = NSFetchRequest(entityName: "Record")
            let predicate2 = NSPredicate(format: "date == %@", saveDate)
            request2.predicate = predicate2
            var error2: NSError?
            let recordList2 = managedContext.executeFetchRequest(request2, error: &error2) as! [Record]
            if recordList2.count != 0 {
                if currentDate == saveDate {
                    recordList2.first!.date      = saveDate
                    recordList2.first!.time1     = time1
                    recordList2.first!.time2     = time2
                    recordList2.first!.time3     = time3
                    recordList2.first!.time4     = time4
                    recordList2.first!.comment   = comment
                    recordList2.first!.totalHor  = totalHor
                    recordList2.first!.totalMin  = totalMin
                    return managedContext.save(&error)
                } else {
//                    let jaTem = UIAlertController(title: "Atenção!", message: "Já existem um registro nessa data. Deseja manter a atual ou efetuar a alteração assim mesmo? ", preferredStyle: UIAlertControllerStyle.Alert)
//                    jaTem.addAction(UIAlertAction(title: "Alteração", style: .Destructive, handler: { (action: UIAlertAction!) in }))
//                    jaTem.addAction(UIAlertAction(title: "Manter", style: .Default, handler: { (action: UIAlertAction!) in }))
//                    self.presentViewController(jaTem, animated: true, completion: nil )
                    return false
                }
            } else {
                if saveData(Date: saveDate, Time1: time1, Time2: time2, Time3: time3, Time4: time4, Comment: comment, TotalHor: totalHor, TotalMin: totalMin) {
                    if removeRecordByDate(currentDate) {
                        return true
                    }
                }
                
            }
        }
        return false
    }
    
    // MARK: - Remove (Record)

    func removeRecordByDate(date: NSDate) -> Bool {
        let request = NSFetchRequest(entityName: "Record")
        let predicate = NSPredicate(format: "date == %@", date)
        request.predicate = predicate
        var error: NSError?
        var record = managedContext.executeFetchRequest(request, error: &error) as! [Record]?
        if record!.count > 0 {
            managedContext.deleteObject(record!.first!)
            return managedContext.save(&error)
        } else {
            return false
        }
    }
    
    func removeAllRecords() -> Bool {
        let request = NSFetchRequest(entityName: "Record")
        var error: NSError?
        let recordList = managedContext.executeFetchRequest(request, error: &error) as! [Record]
        
        if recordList.count > 0 {
            for valor in 0...(recordList.count - 1){
                let record = recordList[valor]
                managedContext.deleteObject(record)
            }
            return managedContext.save(&error)
        }
        return false
    }
    
    // MARK: - Create (DefaulTime)
    
    func saveDataDefaultTime(Time1 time1: String, Time2 time2: String, Time3 time3: String, Time4 time4: String, TotalHor totalHor: Int16, TotalMin totalMin: Int16) -> Bool {
        let userEntity = NSEntityDescription.entityForName("DefaultTime", inManagedObjectContext: managedContext)
        let defaultTime = DefaultTime(entity: userEntity!, insertIntoManagedObjectContext: managedContext)
        defaultTime.totalMin = totalMin
        defaultTime.totalHor = totalHor
        defaultTime.time4 = time4
        defaultTime.time3 = time3
        defaultTime.time2 = time2
        defaultTime.time1 = time1
        var error: NSError?
        return managedContext.save(&error)
    }
    
    // MARK: - Read (DefaulTime)
    
    func getAllDefaultTime() -> NSArray {
        let request = NSFetchRequest(entityName: "DefaultTime")
        var error: NSError?
        let defaultTimeList = managedContext.executeFetchRequest(request, error: &error) as! [DefaultTime]?
        let defaultTimeArray = NSArray(array: defaultTimeList!)
        return defaultTimeArray
    }
    
    // MARK: - Update (DefaulTime)

    func updateDefaulTime(Time1 time1: String, Time2 time2: String, Time3 time3: String, Time4 time4: String, TotalHor totalHor: Int16, TotalMin totalMin: Int16) -> Bool{
        let request = NSFetchRequest(entityName: "DefaultTime")
        var error: NSError?
        let defaultTimeList = managedContext.executeFetchRequest(request, error: &error) as! [DefaultTime]
        if defaultTimeList.count > 0 {
            for defaultTime in defaultTimeList {
                defaultTime.totalMin = totalMin
                defaultTime.totalHor = totalHor
                defaultTime.time1 = time1
                defaultTime.time2 = time2
                defaultTime.time3 = time3
                defaultTime.time4 = time4
            }
            return managedContext.save(&error)
        }
        return false
    }
    
    // MARK: - Remove (DefaulTime)

}